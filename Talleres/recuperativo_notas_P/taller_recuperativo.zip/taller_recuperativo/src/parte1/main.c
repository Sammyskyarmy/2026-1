#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int main(){

    //implementa tus funciones y tus pruebas aca

    return 0;
}